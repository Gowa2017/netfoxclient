inireloc - tool to set different ini locations

This tool sets different locations for the files wincmd.ini and wcx_ftp.ini
for the program "Total Commander". The older Wincmd is no longer supported!

Author:
Christian Ghisler
http://www.ghisler.com


Changelog:
20040916 Fixed: when giving different locations for wincmd.ini+wcx_ftp.ini, the tool sometimes stored the wrong name
20021029 initial release